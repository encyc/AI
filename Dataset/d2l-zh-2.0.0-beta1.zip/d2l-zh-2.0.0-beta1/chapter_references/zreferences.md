```eval_rst

.. only:: html

   参考文献
   ==========

```

:bibliography:`../d2l.bib`

